export const STAGES = [
  { key: "new", label: "New lead" },
  { key: "contacted", label: "Contacted" },
  { key: "appointment", label: "Appointment set" },
  { key: "quoted", label: "Quoted" },
  { key: "application", label: "Application" },
  { key: "inforce", label: "Policy in force" },
] as const;

export const PARKED = [
  { key: "callback", label: "Call back" },
  { key: "notinterested", label: "Not interested" },
  { key: "dnc", label: "Do not call" },
] as const;

export const ALL_STAGES = [...STAGES, ...PARKED];

export const stageLabel = (k: string) => ALL_STAGES.find((s) => s.key === k)?.label ?? k;

export function nextStage(k: string): string | null {
  const i = STAGES.findIndex((s) => s.key === k);
  if (i < 0 || i === STAGES.length - 1) return null;
  return STAGES[i + 1]!.key;
}

/** Tailwind classes for a stage pill (semantic tokens only). */
export function stageTone(k: string) {
  if (k === "inforce" || k === "application") return "bg-success-soft text-success";
  if (k === "callback") return "bg-warning-soft text-warning";
  if (k === "notinterested" || k === "dnc") return "bg-danger-soft text-danger";
  if (k === "new") return "bg-muted text-muted-foreground";
  return "bg-sky-soft text-primary";
}
